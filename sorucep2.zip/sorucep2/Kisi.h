#ifndef KISI_H
#define KISI_H

class Kisi
{
	public:
	char adSoyad[30]; 
	float puan ; 
	
};

#endif

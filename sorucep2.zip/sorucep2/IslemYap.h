#ifndef ISLEMYAP_H
#define ISLEMYAP_H
#include "Kisi.h"
#include "Soru.h"


class IslemYap
{
	public:
	Kisi k1; 
	Soru s1; 
	
	void kisiEkle() ; 
	void soruEkle(); 
	void kisiler(); 
	void sorular(); 
	void sonuclar(); 
	void sinavBasla(); 
	void sinavYap(); 
	int menu (); 
	void giris(); 
	
		
};

#endif

#include "IslemYap.h"
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>

using namespace std; 

void IslemYap:: kisiEkle() 
{
	system("cls") ; 
	cout<<"Kisi ekleme..."<< endl; 
	cout<<"Ad Soyad : ";  cin.getline (  k1.adSoyad, 30, '\n') ; 
	k1.puan= 0.0f; 
	ofstream file("kisiler.txt " , ios::app  ) ; 
	file.write((char*)&k1, sizeof(Kisi))  ; 
	file.close() ; 
	cout<<"Kisi kaydi tamam "<< endl; 
	system("pause") ; 
	
		
}
void IslemYap:: soruEkle()
{
	system("cls") ; 
	cout<<"Soru ekleme..."<< endl; 
	cout<<"Soru metni : ";  cin.getline (  s1.soruMetni, 200, '\n') ; 
	cout<<"A Secenegi : ";  cin.getline (  s1.aSec, 30, '\n') ;
	cout<<"B Secenegi : ";  cin.getline (  s1.bSec, 30, '\n') ;
	cout<<"C Secenegi : ";  cin.getline (  s1.cSec, 30, '\n') ;
	cout<<"D Secenegi : ";  cin.getline (  s1.dSec, 30, '\n') ;
	cout<<"Dogru cevap   : ";  cin.getline ( s1.dCevap, 2, '\n') ;

	ofstream file("sorular.txt " , ios::app  ) ; 
	file.write((char*)&s1, sizeof(Soru ))  ; 
	file.close() ; 
	cout<<"Soru kaydi tamam "<< endl; 
	system("pause") ; 
	
}
void IslemYap:: kisiler()
{
	system("cls") ; 
	ifstream file( "kisiler.txt" ) ; 
	cout<<"\nKayitli Kisiler ..."<< endl<< endl ; 
	while( file.read((char*)&k1, sizeof(Kisi) ) != NULL ) 
	{
		cout<<k1.adSoyad<<  endl; 
	 } 
	 
	 file.close() ; 
	 cout<<endl; 
	 system("pause") ; 
	 
}
void IslemYap:: sorular() 
{
	system("cls") ; 
	int i=0; 
	ifstream file( "sorular.txt" ) ; 
	while( file.read((char*)&s1, sizeof(Soru ) ) != NULL ) 
	{
		i++; 
		cout<<endl<<i<< ". soru : " << s1.soruMetni<<  endl<< endl ; 
		cout<<"A) "<< s1.aSec<<  endl ; 
		cout<<"B) "<< s1.bSec<<  endl ; 
		cout<<"C) "<< s1.cSec<<  endl ; 
		cout<<"D) "<< s1.dSec<<  endl ; 
		cout<<"Dogru Cevap :  "<< s1.dCevap<<  endl<< endl ; 
			
	} 
	 
	 file.close() ; 	 
	 system("pause") ; 	
}

void IslemYap:: sonuclar()
{
	system("cls") ; 
	cout<<"\nSonuclar..."<< endl<< endl; 
	ifstream file( "SinavOlanKisiler.txt" ) ; 
	while( file.read((char*)&k1, sizeof(Kisi) ) != NULL ) 
	{
		cout<<k1.adSoyad<< "\t"<< k1.puan<< endl; 
	 } 
	 
	 file.close() ; 
	 cout<<endl<< endl; 
	 system("pause") ; 
	
	
}
void IslemYap:: sinavBasla()
{
	int dogru=0, yanlis=0; 
	float puan=0; 
	
	system("cls") ; 
	int i=0; 
	char cvp[2]; 
	ifstream file( "sorular.txt" ) ; 
	while( file.read((char*)&s1, sizeof(Soru ) ) != NULL ) 
	{
		i++; 
		cout<<endl<<i<< ". soru : " << s1.soruMetni<<  endl<< endl ; 
		cout<<"A) "<< s1.aSec<<  endl ; 
		cout<<"B) "<< s1.bSec<<  endl ; 
		cout<<"C) "<< s1.cSec<<  endl ; 
		cout<<"D) "<< s1.dSec<<  endl ; 
		cout<<"Cevabiniz ?  :  "; cin.getline(cvp, 2, '\n') ; 
		if (strcmp( cvp, s1.dCevap ) ==0 )
		dogru++; 
		else
		yanlis++; 
	} 
	 
	 file.close() ;
	 
	 puan=  ( (float) dogru / (  dogru + yanlis)  )  * 100;
	 system("cls") ;  
	 cout<<"Sinaviniz bitti..."<< endl; 
	 cout<<"Dogru sayisi  : "<< dogru << endl; 
	 cout<<"Yanlis sayisi : "<< yanlis << endl;
	 cout<<"Puaniniz      : "<< puan << endl;
	 
	 k1.puan= puan ; 
	 
	ofstream ofile("SinavOlanKisiler.txt " , ios::app  ) ; 
	ofile.write((char*)&k1, sizeof(Kisi))  ; 
	ofile.close() ; 
	cout<<"Sonuc kayit edildi  "<< endl ;
	  	 
	 system("pause") ; 	
	
}
void IslemYap:: sinavYap()
{
	system("cls") ; 
	Kisi k2; 
	cout<<"Sinava girecek kisinin ..."<< endl; 
	cout<<"Ad Soyad : ";  cin.getline (  k2.adSoyad, 30, '\n') ; 
	bool varmi=false; 
	ifstream file("kisiler.txt " , ios::app  ) ; 
	while( file.read((char*)&k1, sizeof(Kisi) ) != NULL ) 
	{
		if(  strcmp( k1.adSoyad, k2.adSoyad)==0   ) 
		{
			cout<<k1.adSoyad<< endl; 
			varmi= true; 
			cout<<"Baslamak icin bir tusa basiniz...  "<< endl;  
			break; 
		}
	 } 
	 
	 file.close() ; 
	 
	 if( varmi)
	 sinavBasla( ); 
	 else
	{
		 cout<<k2.adSoyad << " once kayit olunuz !"<< endl; 
		 system("pause") ;	 	
	 }
 
	
}
int IslemYap:: menu ()
{
	system("cls")  ; 
	int secim; 
	char tercih[2]; 
	cout<< "\n\t SORU - CEVAP UYGULAMASI \n"<< endl; 
	cout<<"\t[1]- Sinav Yap "<< endl; 
	cout<<"\t[2]- Kisi Ekle "<< endl; 
	cout<<"\t[3]- Soru Ekle "<< endl; 
	cout<<"\t[4]- Kisiler"<< endl; 
	cout<<"\t[5]- Sorular"<< endl; 
	cout<<"\t[6]- Sonuclar "<< endl; 
	cout<<"\t[0]- CIKIS "<< endl;
	cout<<"Seciminiz   : " ; cin.getline(tercih, 2, '\n') ; 
	secim= atoi(tercih); 
	return secim; 
}
void IslemYap:: giris()
{
	
	int secim= menu(); 
	while( secim != 0)
	{
		switch(secim ) 
		{
			case 1: sinavYap() ;break; 
			case 2: kisiEkle(); break; 
			case 3: soruEkle(); break; 
			case 4: kisiler() ; break; 
			case 5: sorular() ; break; 
			case 6: sonuclar(); break; 
			default: cout<<"Hatali secim !!! "<< endl; break; 
		}
		secim= menu(); 
	} 
}





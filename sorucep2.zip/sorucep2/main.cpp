#include <iostream>
#include "IslemYap.h"

// SORU- CEVAP UYGULAMASI
// Sad�k �AH�N- Bilgisayar M�hendisi 

int main(int argc, char** argv) {
	
	IslemYap iy1; 
	
	iy1.giris() ; 
	
	
	
	return 0;
}

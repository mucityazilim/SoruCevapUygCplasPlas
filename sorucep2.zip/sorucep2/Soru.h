#ifndef SORU_H
#define SORU_H

class Soru
{
	public:
		char soruMetni[200], aSec[20], bSec[20], cSec[20], dSec[20], dCevap[2] ; 
		
};

#endif
